//
//  ViewController.h
//  CordovoTest
//
//  Created by mm on 16/11/30.
//  Copyright © 2016年 mm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDVViewController.h"

@interface ViewController : CDVViewController


@end

