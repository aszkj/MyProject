//
//  ViewController.m
//  CordovoTest
//
//  Created by mm on 16/11/30.
//  Copyright © 2016年 mm. All rights reserved.
//

#import "ViewController.h"
#import "HaleyPlugin.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *testWebView;




@end

@implementation ViewController

- (void)viewDidLoad {

//    self.wwwFolderName = @"http://";
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recievie:) name:@"haha" object:nil];
//    self.startPage = @"http://www.baidu.com";
     [self performSelector:@selector(testAA) withObject:nil afterDelay:1];
}

- (void)recievie:(NSNotification *)info {
    NSLog(@"haha");
}

- (void)testAA  {
//    self.wwwFolderName = @"http://";
//    self.startPage = @"http://www.baidu.com";
//    NSURL *url = [self performSelector:@selector(appUrl)];
//    if (url)
//    {
//        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
//        [self.webViewEngine loadRequest:request];
//    }
//    NSString* path = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];
//    NSURL* url = [NSURL fileURLWithPath:path];
//    NSURLRequest* request = [NSURLRequest requestWithURL:url] ;
//    [webView loadRequest:request];
    self.wwwFolderName = @"www";
    self.startPage = @"index";
    NSURL *url = [self performSelector:@selector(appUrl)];
    if (url)
    {
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
        [self.webViewEngine loadRequest:request];
    }
    HaleyPlugin *plugin = (HaleyPlugin *)[self getCommandInstance:@"HaleyPlugin"];
    plugin.jsTransValueBlock = ^{
        NSLog(@"hehe");
    };
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
