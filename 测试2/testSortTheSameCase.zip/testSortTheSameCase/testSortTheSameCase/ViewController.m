//
//  ViewController.m
//  testSortTheSameCase
//
//  Created by mm on 16/12/15.
//  Copyright © 2016年 mm. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *testArr = @[@"a",@"b",@"b",@"c",@"c",@"d",@"d"];
    NSMutableArray *outBigArr = [NSMutableArray arrayWithCapacity:0];
    NSInteger k=0;
    BOOL isDiffrentBegin = NO;
    NSMutableArray *inSmallArr = [NSMutableArray arrayWithCapacity:0];
    for (NSInteger i=0; i<testArr.count; i++) {
        NSString *currentStr = testArr[i];
        if (isDiffrentBegin || i == 0) {
            [inSmallArr addObject:currentStr];
        }
        if (i<=testArr.count-2) {
            NSString *nextStr = testArr[i+1];
            if ([currentStr isEqualToString:nextStr]) {
                isDiffrentBegin = NO;
                [inSmallArr addObject:nextStr];
            }else{
                [outBigArr addObject:inSmallArr];
                isDiffrentBegin = YES;
                inSmallArr = [NSMutableArray arrayWithCapacity:0];
            }
        }else {
            if (!isDiffrentBegin) {
                [outBigArr addObject:inSmallArr];
            }
        }
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
